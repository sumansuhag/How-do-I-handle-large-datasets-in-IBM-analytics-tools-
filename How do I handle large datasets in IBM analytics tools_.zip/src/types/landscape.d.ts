export interface LibraryNode {
  id: string;
  name: string;
  layer: string;
  description: string;
  relationships: string[];
  x: number;
  y: number;
  color: string;
}

export interface Layer {
  id: string;
  name: string;
  color: string;
  icon: React.ComponentType<any>;
  position: number;
}

export interface Connection {
  from: string;
  to: string;
}