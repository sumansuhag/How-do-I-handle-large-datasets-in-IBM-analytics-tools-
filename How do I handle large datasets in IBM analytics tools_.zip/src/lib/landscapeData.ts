import { LibraryNode, Layer, Connection } from '../types/landscape';
import { Book, Server, ChartLine, Package, Network, Database, BarChart3, Scale, Cpu } from 'lucide-react';

export const layers: Layer[] = [
  { id: 'foundations', name: 'Foundations', color: '#3b82f6', icon: Book, position: 0 },
  { id: 'package_management', name: 'Package Management', color: '#10b981', icon: Package, position: 1 },
  { id: 'application_frameworks', name: 'Application Frameworks', color: '#f59e0b', icon: Server, position: 2 },
  { id: 'network_resources', name: 'Network Resources', color: '#ef4444', icon: Network, position: 3 },
  { id: 'data_access', name: 'Data Access', color: '#8b5cf6', icon: Database, position: 4 },
  { id: 'data_representation', name: 'Data Representation', color: '#ec4899', icon: BarChart3, position: 5 },
  { id: 'analysis_modeling', name: 'Analysis & Modeling', color: '#06b6d4', icon: Cpu, position: 6 },
  { id: 'visualization', name: 'Visualization', color: '#84cc16', icon: ChartLine, position: 7 },
  { id: 'explainability', name: 'Explainability/Fairness', color: '#64748b', icon: Scale, position: 8 }
];

export const libraries: LibraryNode[] = [
  // Foundations
  { id: 'python', name: 'Python', layer: 'foundations', description: 'The core programming language for data science', relationships: ['numpy', 'pandas', 'scikit-learn'], x: 0, y: 0, color: '#3b82f6' },
  { id: 'numpy', name: 'NumPy', layer: 'foundations', description: 'Fundamental package for scientific computing with Python', relationships: ['pandas', 'scipy', 'matplotlib'], x: 0, y: 1, color: '#3b82f6' },
  { id: 'scipy', name: 'SciPy', layer: 'foundations', description: 'Library for mathematics, science, and engineering', relationships: ['numpy', 'scikit-learn'], x: 0, y: 2, color: '#3b82f6' },

  // Package Management
  { id: 'pip', name: 'pip', layer: 'package_management', description: 'Python package installer and manager', relationships: ['conda', 'poetry'], x: 1, y: 0, color: '#10b981' },
  { id: 'conda', name: 'Conda', layer: 'package_management', description: 'Package and environment management system', relationships: ['pip', 'anaconda'], x: 1, y: 1, color: '#10b981' },
  { id: 'poetry', name: 'Poetry', layer: 'package_management', description: 'Python dependency management and packaging', relationships: ['pip'], x: 1, y: 2, color: '#10b981' },

  // Application Frameworks
  { id: 'jupyter', name: 'Jupyter', layer: 'application_frameworks', description: 'Interactive computing environment for notebooks', relationships: ['jupyterhub', 'voila'], x: 2, y: 0, color: '#f59e0b' },
  { id: 'jupyterhub', name: 'JupyterHub', layer: 'application_frameworks', description: 'Multi-user server for Jupyter notebooks', relationships: ['jupyter'], x: 2, y: 1, color: '#f59e0b' },
  { id: 'voila', name: 'Voila', layer: 'application_frameworks', description: 'Turns Jupyter notebooks into standalone web applications', relationships: ['jupyter'], x: 2, y: 2, color: '#f59e0b' },

  // Network Resources
  { id: 'requests', name: 'Requests', layer: 'network_resources', description: 'HTTP library for human beings', relationships: ['flask', 'django'], x: 3, y: 0, color: '#ef4444' },
  { id: 'flask', name: 'Flask', layer: 'network_resources', description: 'Lightweight WSGI web application framework', relationships: ['requests'], x: 3, y: 1, color: '#ef4444' },
  { id: 'django', name: 'Django', layer: 'network_resources', description: 'High-level Python web framework', relationships: ['requests'], x: 3, y: 2, color: '#ef4444' },

  // Data Access
  { id: 'sqlalchemy', name: 'SQLAlchemy', layer: 'data_access', description: 'SQL toolkit and Object-Relational Mapping library', relationships: ['pandas', 'django'], x: 4, y: 0, color: '#8b5cf6' },
  { id: 'pyarrow', name: 'PyArrow', layer: 'data_access', description: 'Python library for Apache Arrow', relationships: ['pandas', 'spark'], x: 4, y: 1, color: '#8b5cf6' },
  { id: 'pyspark', name: 'PySpark', layer: 'data_access', description: 'Python API for Apache Spark', relationships: ['pyarrow', 'pandas'], x: 4, y: 2, color: '#8b5cf6' },

  // Data Representation
  { id: 'pandas', name: 'Pandas', layer: 'data_representation', description: 'Data manipulation and analysis library', relationships: ['numpy', 'matplotlib', 'scikit-learn'], x: 5, y: 0, color: '#ec4899' },
  { id: 'dask', name: 'Dask', layer: 'data_representation', description: 'Parallel computing library for analytics', relationships: ['pandas', 'numpy'], x: 5, y: 1, color: '#ec4899' },
  { id: 'xarray', name: 'XArray', layer: 'data_representation', description: 'N-D labeled arrays and datasets', relationships: ['pandas', 'numpy'], x: 5, y: 2, color: '#ec4899' },

  // Analysis & Modeling
  { id: 'scikit-learn', name: 'scikit-learn', layer: 'analysis_modeling', description: 'Machine learning library for Python', relationships: ['numpy', 'pandas', 'matplotlib'], x: 6, y: 0, color: '#06b6d4' },
  { id: 'tensorflow', name: 'TensorFlow', layer: 'analysis_modeling', description: 'Open source machine learning framework', relationships: ['keras', 'numpy'], x: 6, y: 1, color: '#06b6d4' },
  { id: 'pytorch', name: 'PyTorch', layer: 'analysis_modeling', description: 'Open source machine learning framework', relationships: ['numpy', 'scikit-learn'], x: 6, y: 2, color: '#06b6d4' },

  // Visualization
  { id: 'matplotlib', name: 'Matplotlib', layer: 'visualization', description: 'Comprehensive library for static, animated, and interactive visualizations', relationships: ['numpy', 'pandas'], x: 7, y: 0, color: '#84cc16' },
  { id: 'seaborn', name: 'Seaborn', layer: 'visualization', description: 'Statistical data visualization library', relationships: ['matplotlib', 'pandas'], x: 7, y: 1, color: '#84cc16' },
  { id: 'plotly', name: 'Plotly', layer: 'visualization', description: 'Interactive graphing library', relationships: ['dash', 'pandas'], x: 7, y: 2, color: '#84cc16' },

  // Explainability/Fairness
  { id: 'shap', name: 'SHAP', layer: 'explainability', description: 'Game theoretic approach to explain machine learning models', relationships: ['scikit-learn', 'tensorflow'], x: 8, y: 0, color: '#64748b' },
  { id: 'lime', name: 'LIME', layer: 'explainability', description: 'Local Interpretable Model-agnostic Explanations', relationships: ['scikit-learn'], x: 8, y: 1, color: '#64748b' },
  { id: 'fairlearn', name: 'Fairlearn', layer: 'explainability', description: 'Toolkit for assessing and improving fairness of AI systems', relationships: ['scikit-learn'], x: 8, y: 2, color: '#64748b' }
];

export const connections: Connection[] = [
  { from: 'python', to: 'numpy' },
  { from: 'python', to: 'pandas' },
  { from: 'numpy', to: 'pandas' },
  { from: 'numpy', to: 'scipy' },
  { from: 'scipy', to: 'scikit-learn' },
  { from: 'pip', to: 'conda' },
  { from: 'jupyter', to: 'jupyterhub' },
  { from: 'jupyter', to: 'voila' },
  { from: 'requests', to: 'flask' },
  { from: 'requests', to: 'django' },
  { from: 'sqlalchemy', to: 'pandas' },
  { from: 'pyarrow', to: 'pandas' },
  { from: 'pyarrow', to: 'pyspark' },
  { from: 'pandas', to: 'matplotlib' },
  { from: 'pandas', to: 'scikit-learn' },
  { from: 'dask', to: 'pandas' },
  { from: 'scikit-learn', to: 'tensorflow' },
  { from: 'scikit-learn', to: 'pytorch' },
  { from: 'matplotlib', to: 'seaborn' },
  { from: 'plotly', to: 'dash' },
  { from: 'shap', to: 'scikit-learn' },
  { from: 'lime', to: 'scikit-learn' },
  { from: 'fairlearn', to: 'scikit-learn' }
];