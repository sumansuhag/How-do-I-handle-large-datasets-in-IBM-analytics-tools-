import React, { useState } from 'react';
import PerformanceDashboard from './components/PerformanceDashboard';
import { Card, CardContent } from './components/ui/card';
import { BarChart3, Cpu, Database, Zap, Clock, TrendingUp } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-slate-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <header className="text-center mb-8">
          <h1 className="text-3xl font-bold text-slate-800 mb-2">
            IBM Analytics Performance Optimizer
          </h1>
          <p className="text-slate-600">
            Dashboard for Soumitra Dutta's large dataset performance challenges
          </p>
        </header>
        
        <PerformanceDashboard />
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <QuickStatCard 
            icon={<Database className="w-8 h-8" />} 
            title="Dataset Size" 
            value="2.4TB" 
            description="Current active datasets"
          />
          <QuickStatCard 
            icon={<Clock className="w-8 h-8" />} 
            title="Avg Query Time" 
            value="47s" 
            description="Across all operations"
          />
          <QuickStatCard 
            icon={<TrendingUp className="w-8 h-8" />} 
            title="Potential Improvement" 
            value="68%" 
            description="With optimizations"
          />
        </div>
      </div>
    </div>
  );
}

const QuickStatCard = ({ icon, title, value, description }) => (
  <Card className="bg-white border-slate-200">
    <CardContent className="p-6 text-center">
      <div className="text-blue-600 mb-3 flex justify-center">{icon}</div>
      <h3 className="text-lg font-semibold text-slate-800 mb-1">{title}</h3>
      <p className="text-2xl font-bold text-slate-900 mb-2">{value}</p>
      <p className="text-sm text-slate-500">{description}</p>
    </CardContent>
  </Card>
);

export default App;