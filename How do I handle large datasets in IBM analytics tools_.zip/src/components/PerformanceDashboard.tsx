import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { BarChart3, Cpu, Database, Zap, Clock, CheckCircle, AlertCircle } from 'lucide-react';

const PerformanceDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');

  const performanceData = {
    queryTimes: [
      { name: 'Data Load', current: 120, optimized: 45 },
      { name: 'Aggregation', current: 85, optimized: 28 },
      { name: 'Join Operations', current: 210, optimized: 75 },
      { name: 'Export', current: 65, optimized: 22 }
    ],
    recommendations: [
      {
        id: 1,
        title: 'Implement Data Partitioning',
        description: 'Partition large tables by date or category to reduce scan operations',
        impact: 'High',
        effort: 'Medium',
        status: 'pending'
      },
      {
        id: 2,
        title: 'Use Columnar Storage',
        description: 'Convert to columnar format for better compression and faster scans',
        impact: 'High',
        effort: 'High',
        status: 'in-progress'
      },
      {
        id: 3,
        title: 'Query Optimization',
        description: 'Rewrite complex queries and add appropriate indexes',
        impact: 'Medium',
        effort: 'Low',
        status: 'completed'
      },
      {
        id: 4,
        title: 'Cache Frequently Used Data',
        description: 'Implement in-memory caching for frequently accessed datasets',
        impact: 'Medium',
        effort: 'Medium',
        status: 'pending'
      }
    ],
    resourceUsage: {
      cpu: 85,
      memory: 72,
      disk: 63,
      network: 45
    }
  };

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-4 mb-6">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="recommendations" className="flex items-center gap-2">
            <Zap className="w-4 h-4" />
            Recommendations
          </TabsTrigger>
          <TabsTrigger value="resources" className="flex items-center gap-2">
            <Cpu className="w-4 h-4" />
            Resources
          </TabsTrigger>
          <TabsTrigger value="analysis" className="flex items-center gap-2">
            <Database className="w-4 h-4" />
            Analysis
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <OverviewTab data={performanceData} />
        </TabsContent>

        <TabsContent value="recommendations">
          <RecommendationsTab data={performanceData.recommendations} />
        </TabsContent>

        <TabsContent value="resources">
          <ResourcesTab data={performanceData.resourceUsage} />
        </TabsContent>

        <TabsContent value="analysis">
          <AnalysisTab />
        </TabsContent>
      </Tabs>
    </div>
  );
};

const OverviewTab = ({ data }) => (
  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
    <Card className="bg-white">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="w-5 h-5" />
          Query Performance
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {data.queryTimes.map((item, index) => (
            <div key={index} className="flex justify-between items-center p-3 bg-slate-50 rounded-lg">
              <span className="font-medium">{item.name}</span>
              <div className="text-right">
                <div className="text-red-500 line-through">{item.current}s</div>
                <div className="text-green-600 font-semibold">{item.optimized}s</div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>

    <Card className="bg-white">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="w-5 h-5" />
          Optimization Impact
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span>Data Processing</span>
            <span className="text-green-600 font-semibold">62% faster</span>
          </div>
          <div className="flex justify-between items-center">
            <span>Memory Usage</span>
            <span className="text-green-600 font-semibold">45% reduction</span>
          </div>
          <div className="flex justify-between items-center">
            <span>Cost Efficiency</span>
            <span className="text-green-600 font-semibold">38% savings</span>
          </div>
        </div>
      </CardContent>
    </Card>
  </div>
);

const RecommendationsTab = ({ data }) => (
  <div className="space-y-4">
    {data.map((item) => (
      <Card key={item.id} className="bg-white">
        <CardContent className="p-6">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h3 className="font-semibold text-lg mb-2">{item.title}</h3>
              <p className="text-slate-600 mb-3">{item.description}</p>
              <div className="flex gap-4 text-sm">
                <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded">
                  Impact: {item.impact}
                </span>
                <span className="bg-orange-100 text-orange-800 px-2 py-1 rounded">
                  Effort: {item.effort}
                </span>
              </div>
            </div>
            <div className="ml-4">
              {item.status === 'completed' && (
                <CheckCircle className="w-6 h-6 text-green-500" />
              )}
              {item.status === 'in-progress' && (
                <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
              )}
              {item.status === 'pending' && (
                <AlertCircle className="w-6 h-6 text-orange-500" />
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    ))}
  </div>
);

const ResourcesTab = ({ data }) => (
  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
    <Card className="bg-white">
      <CardHeader>
        <CardTitle>Resource Utilization</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {Object.entries(data).map(([key, value]) => (
            <div key={key}>
              <div className="flex justify-between mb-1">
                <span className="capitalize font-medium">{key}</span>
                <span className={value > 80 ? 'text-red-500' : value > 60 ? 'text-orange-500' : 'text-green-500'}>
                  {value}%
                </span>
              </div>
              <div className="w-full bg-slate-200 rounded-full h-2">
                <div
                  className={`h-2 rounded-full ${
                    value > 80 ? 'bg-red-500' : value > 60 ? 'bg-orange-500' : 'bg-green-500'
                  }`}
                  style={{ width: `${value}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>

    <Card className="bg-white">
      <CardHeader>
        <CardTitle>Optimization Tips</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-3 list-disc list-inside text-slate-700">
          <li>Use IBM Db2 BLU Acceleration for columnar storage</li>
          <li>Implement data partitioning strategies</li>
          <li>Leverage in-memory databases for hot data</li>
          <li>Optimize JOIN operations with proper indexes</li>
          <li>Use compression for large datasets</li>
          <li>Implement query caching mechanisms</li>
        </ul>
      </CardContent>
    </Card>
  </div>
);

const AnalysisTab = () => (
  <Card className="bg-white">
    <CardHeader>
      <CardTitle>Performance Analysis</CardTitle>
    </CardHeader>
    <CardContent>
      <div className="space-y-4">
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <h4 className="font-semibold text-blue-800 mb-2">IBM-Specific Recommendations</h4>
          <ul className="list-disc list-inside text-blue-700 space-y-1">
            <li>Utilize IBM Watson Studio for machine learning optimization</li>
            <li>Implement IBM Db2 with BLU Acceleration for columnar processing</li>
            <li>Use IBM Spectrum Scale for parallel file system operations</li>
            <li>Leverage IBM Cloud Pak for Data for integrated analytics</li>
          </ul>
        </div>

        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
          <h4 className="font-semibold text-green-800 mb-2">Best Practices for Large Datasets</h4>
          <ul className="list-disc list-inside text-green-700 space-y-1">
            <li>Implement incremental data processing instead of full scans</li>
            <li>Use appropriate data compression algorithms</li>
            <li>Design efficient data models with proper normalization/denormalization</li>
            <li>Schedule heavy operations during off-peak hours</li>
          </ul>
        </div>
      </div>
    </CardContent>
  </Card>
);

export default PerformanceDashboard;