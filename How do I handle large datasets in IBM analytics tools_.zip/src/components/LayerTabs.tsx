import React from 'react';
import { Tabs, TabsList, TabsTrigger } from '../components/ui/tabs';
import { layers } from '../lib/landscapeData';

interface LayerTabsProps {
  activeLayer: string | null;
  onLayerChange: (layer: string) => void;
}

export const LayerTabs: React.FC<LayerTabsProps> = ({ activeLayer, onLayerChange }) => {
  return (
    <Tabs value={activeLayer || ''} onValueChange={onLayerChange} className="w-full">
      <TabsList className="flex w-full justify-start overflow-x-auto">
        {layers.map((layer) => {
          const Icon = layer.icon;
          return (
            <TabsTrigger
              key={layer.id}
              value={layer.id}
              className="flex items-center gap-2 px-4 py-2 text-sm whitespace-nowrap"
            >
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: layer.color }}
              />
              <Icon className="w-4 h-4" />
              {layer.name}
            </TabsTrigger>
          );
        })}
      </TabsList>
    </Tabs>
  );
};